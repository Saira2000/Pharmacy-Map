// IQVIA Pharmacy Count Rankings
// Average prescription volumes by province and rank

interface RankRange {
  min: number;
  max: number;
  average: number;
}

type ProvinceRankings = {
  [rank: string]: RankRange;
};

type ProvinceCounts = {
  [province: string]: ProvinceRankings;
};

const prescriptionCounts: ProvinceCounts = {
  'AB': {
    'A': { min: 101000, max: Number.POSITIVE_INFINITY, average: 101000 },
    'B': { min: 71500, max: 101000, average: 86250 },
    'C': { min: 55000, max: 71500, average: 63250 },
    'D': { min: 32000, max: 55000, average: 43500 },
    'E': { min: 0, max: 32000, average: 16000 }
  },
  'BC': {
    'A': { min: 117000, max: Number.POSITIVE_INFINITY, average: 117000 },
    'B': { min: 75500, max: 117000, average: 96250 },
    'C': { min: 57200, max: 75500, average: 66350 },
    'D': { min: 31500, max: 57500, average: 44500 },
    'E': { min: 0, max: 31500, average: 15750 }
  },
  'MB': {
    'A': { min: 103500, max: Number.POSITIVE_INFINITY, average: 103500 },
    'B': { min: 76000, max: 103500, average: 89750 },
    'C': { min: 61000, max: 76000, average: 68500 },
    'D': { min: 36500, max: 61000, average: 48750 },
    'E': { min: 0, max: 36500, average: 18250 }
  },
  'NB': {
    'A': { min: 113500, max: Number.POSITIVE_INFINITY, average: 113500 },
    'B': { min: 82000, max: 113500, average: 97750 },
    'C': { min: 65000, max: 82000, average: 73500 },
    'D': { min: 38000, max: 65000, average: 51500 },
    'E': { min: 0, max: 38000, average: 19000 }
  },
  'NL': { // NE & PEI (Newfoundland and PEI)
    'A': { min: 105500, max: Number.POSITIVE_INFINITY, average: 105500 },
    'B': { min: 71500, max: 105500, average: 88500 },
    'C': { min: 58000, max: 71500, average: 64750 },
    'D': { min: 36500, max: 58000, average: 47250 },
    'E': { min: 0, max: 36500, average: 18250 }
  },
  'PE': { // PEI
    'A': { min: 105500, max: Number.POSITIVE_INFINITY, average: 105500 },
    'B': { min: 71500, max: 105500, average: 88500 },
    'C': { min: 58000, max: 71500, average: 64750 },
    'D': { min: 36500, max: 58000, average: 47250 },
    'E': { min: 0, max: 36500, average: 18250 }
  },
  'NS': {
    'A': { min: 116500, max: Number.POSITIVE_INFINITY, average: 116500 },
    'B': { min: 71500, max: 116500, average: 94000 },
    'C': { min: 53000, max: 71500, average: 62250 },
    'D': { min: 33000, max: 53000, average: 43000 },
    'E': { min: 0, max: 33000, average: 16500 }
  },
  'ON': {
    'A': { min: 143500, max: Number.POSITIVE_INFINITY, average: 143500 },
    'B': { min: 80000, max: 143500, average: 111750 },
    'C': { min: 60000, max: 80000, average: 70000 },
    'D': { min: 34500, max: 60000, average: 47250 },
    'E': { min: 0, max: 34500, average: 17250 }
  },
  'QC': {
    'A': { min: 260000, max: Number.POSITIVE_INFINITY, average: 260000 },
    'B': { min: 182000, max: 260000, average: 221000 },
    'C': { min: 134500, max: 182000, average: 158250 },
    'D': { min: 85000, max: 134500, average: 109750 },
    'E': { min: 0, max: 85000, average: 42500 }
  },
  'SK': {
    'A': { min: 135000, max: Number.POSITIVE_INFINITY, average: 135000 },
    'B': { min: 100500, max: 135000, average: 117750 },
    'C': { min: 76000, max: 100500, average: 88250 },
    'D': { min: 42000, max: 76000, average: 59000 },
    'E': { min: 0, max: 42000, average: 21000 }
  }
};

export function getPrescriptionCount(province: string | undefined, rank: string | number | undefined): number | null {
  if (!province || !rank) return null;
  
  // Normalize province code
  const provinceCode = province.toUpperCase();
  
  // Normalize rank (convert to string and uppercase)
  const rankKey = String(rank).toUpperCase();
  
  // Look up the prescription count
  const provinceData = prescriptionCounts[provinceCode];
  if (!provinceData) return null;
  
  const rankData = provinceData[rankKey];
  if (!rankData) return null;
  
  return rankData.average;
}

export function formatPrescriptionCount(count: number): string {
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}K Rx`;
  }
  return `${count} Rx`;
}

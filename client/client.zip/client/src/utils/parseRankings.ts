import * as XLSX from 'xlsx';
import rankingsFileUrl from '@assets/PHA Rank Details_1762373184125.xlsx?url';

export interface PharmacyRank {
  address: string;
  rank: number;
}

export async function parseUploadedRankings(file: File): Promise<Map<string, string | number>> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json<any>(firstSheet, { header: 1 });
    return processRankingsData(data);
  } catch (error) {
    console.error('Error parsing uploaded rankings:', error);
    throw error;
  }
}

function processRankingsData(data: any[]): Map<string, string | number> {
  const rankingsMap = new Map<string, string | number>();
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const address = row[2];
    const rank = row[3];
    if (address && rank !== undefined && rank !== null) {
      const normalizedAddress = String(address).trim().toLowerCase();
      rankingsMap.set(normalizedAddress, rank);
    }
  }
  return rankingsMap;
}

export async function loadPharmacyRankings(): Promise<Map<string, string | number>> {
  try {
    const response = await fetch(rankingsFileUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch rankings file: ${response.statusText}`);
    }
    const arrayBuffer = await response.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json<any>(firstSheet, { header: 1 });
    return processRankingsData(data);
  } catch (error) {
    console.error('Error loading pharmacy rankings:', error);
    return new Map();
  }
}

function normalizeAddress(addr: string): string {
  return addr
    .toLowerCase()
    .trim()
    // Remove common unit/apt indicators and everything after
    .replace(/\s*(unit|#|apt|apartment|suite|ste)\s*[a-z0-9-]*/gi, '')
    .replace(/\s+[a-z]\d{2,4}$/i, '') // Remove patterns like "A202", "B15"
    // Normalize street types
    .replace(/\bavenue\b/g, 'ave')
    .replace(/\bstreet\b/g, 'st')
    .replace(/\broad\b/g, 'rd')
    .replace(/\bdrive\b/g, 'dr')
    .replace(/\bcourt\b/g, 'ct')
    .replace(/\bboulevard\b/g, 'blvd')
    .replace(/\bcrescent\b/g, 'cres')
    .replace(/\bhighway\b/g, 'hwy')
    .replace(/\bterrace\b/g, 'terr')
    .replace(/\bplace\b/g, 'pl')
    .replace(/\blane\b/g, 'ln')
    .replace(/\bcircle\b/g, 'cir')
    // Normalize direction indicators to single letters
    .replace(/\beast\b/g, 'e')
    .replace(/\bwest\b/g, 'w')
    .replace(/\bnorth\b/g, 'n')
    .replace(/\bsouth\b/g, 's')
    .replace(/\bsouthwest\b/g, 'sw')
    .replace(/\bsoutheast\b/g, 'se')
    .replace(/\bnorthwest\b/g, 'nw')
    .replace(/\bnortheast\b/g, 'ne')
    // Remove extra spaces
    .replace(/\s+/g, ' ')
    .trim();
}

// Extract city from full address (after first comma)
function extractCity(address: string): string {
  const parts = address.split(',');
  if (parts.length >= 2) {
    return parts[1].trim().toLowerCase();
  }
  return '';
}

export function findRankByAddress(name: string, address: string, rankingsMap: Map<string, string | number>): string | number | null {
  console.log('Finding rank for:', name, 'at', address);
  
  const streetAddress = address.split(',')[0].trim();
  const city = extractCity(address);
  const normalizedSearch = normalizeAddress(streetAddress);
  const searchName = name.toLowerCase();
  
  const streetNumberMatch = streetAddress.match(/^(\d+[-]?\d*)/);
  const streetNumber = streetNumberMatch ? streetNumberMatch[1] : null;
  
  let bestMatch: { rank: string | number; score: number; address: string } | null = null;
  
  const entries = Array.from(rankingsMap.entries());
  for (const [rankKey, rank] of entries) {
    // format: "pharmacy name: address"
    const [rankNamePart, rankAddressOnly] = rankKey.includes(':') 
      ? [rankKey.split(':')[0].trim(), rankKey.split(':')[1].trim()]
      : ['', rankKey];
    
    const rankStreetPart = rankAddressOnly.split(',')[0];
    const rankCity = extractCity(rankAddressOnly);
    const normalizedRank = normalizeAddress(rankStreetPart);
    const rankName = rankNamePart.toLowerCase();
    
    const rankNumberMatch = rankStreetPart.match(/^(\d+[-]?\d*)/);
    const rankStreetNumber = rankNumberMatch ? rankNumberMatch[1] : null;
    
    if (streetNumber && rankStreetNumber && streetNumber !== rankStreetNumber) continue;
    if (!streetNumber) continue;
    
    let score = 0;
    
    // Name match bonus
    if (searchName && rankName) {
      if (searchName.includes(rankName) || rankName.includes(searchName)) {
        score += 40;
      }
    }

    if (city && rankCity && (city.includes(rankCity) || rankCity.includes(city))) {
      score += 50;
    }
    
    const searchWordsAfterNumber = normalizedSearch.replace(/^\d+[-]?\d*\s*/, '').split(' ').filter(w => w.length > 1);
    const rankWordsAfterNumber = normalizedRank.replace(/^\d+[-]?\d*\s*/, '').split(' ').filter(w => w.length > 1);
    
    let exactMatches = 0;
    for (const word of searchWordsAfterNumber) {
      if (rankWordsAfterNumber.includes(word)) {
        exactMatches++;
        score += 10;
      }
    }
    
    if (exactMatches === 0 && searchWordsAfterNumber.length > 0 && score < 40) continue;
    
    if (score > 0 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = { rank, score, address: rankAddressOnly };
    }
  }
  
  if (bestMatch) {
    console.log('✅ Best match found! Rank:', bestMatch.rank, '| Score:', bestMatch.score);
    return bestMatch.rank;
  }
  return null;
}

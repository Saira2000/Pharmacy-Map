// Import pharmacy brand logos (transparent PNG versions)
import brunnetLogo from '@assets/brunet_1762368860326.png';
import coopLogo from '@assets/Co-op_1762368860327.png';
import costcoLogo from '@assets/costco_1762368860327.png';
import familiprixLogo from '@assets/familiprix_1762368860327.png';
import fortinosLogo from '@assets/fortinos_1762368860328.png';
import freshcoLogo from '@assets/Freshco_1762368878826.png';
import guardianLogo from '@assets/guardian_1762371434715.bmp';
import idaLogo from '@assets/IDA_1762368878826.png';
import jeanCoutuLogo from '@assets/Jean Cotu_1762368878827.png';
import loblawsLogo from '@assets/Loblaws_logo_1762369277374.png';
import londonDrugsLogo from '@assets/London Drugs_1762368878828.png';
import maxiLogo from '@assets/maxi_1762368895462.png';
import medicineShoppeLogo from '@assets/Medicine_Shoppe-removebg-preview_1762440584572.png';
import metroLogo from '@assets/Metro_1762368895464.png';
import noFrillsLogo from '@assets/No_Frills_1764862811756.png';
import peoplesDrugMartLogo from '@assets/PeoplesDrugMart_1762368895465.png';
import pharmachoiceLogo from '@assets/Pharmachoice_1764882589171.png';
import pharmasaveLogo from '@assets/Pharmasave_1762369437462.png';
import proximLogo from '@assets/Proxim-removebg-preview_1762440584573.png';
import remedysRxLogo from '@assets/Remedys-Rx_1762439217341.jpg';
import rexallLogo from '@assets/rexall_1762369437464.png';
import safewayLogo from '@assets/safeway_1762369437465.png';
import saveOnFoodsLogo from '@assets/Save on Foods2_1762368964303.png';
import shoppersDrugMartLogo from '@assets/image_1764790467233.png';
import sobeysLogo from '@assets/sobeys_1762368964304.png';
import uniprixLogo from '@assets/uniprix_1762368964304.png';
import valueDrugMartLogo from '@assets/value_drug_mart_1772043972409.png';
import independentGrocerLogo from '@assets/your_independent_grocer_1772043972410.png';
import zehrsLogo from '@assets/zehrs_1762368964305.png';
import walmartLogo from '@assets/walmart-logo-png-25_1762439601037.png';
import valuMartLogo from '@assets/mvalu-mart_1772043972409.png';
import extraFoodsLogo from '@assets/extra-foods-canada-1-400_1772043972408.jpg';
import realCanadianSuperstoreLogo from '@assets/Real_Canadian_Superstore_logo.svg-removebg-preview_1762443118611.png';
import ttLogo from '@assets/OIP-removebg-preview_1772202341616.png';
import independentPharmacyImage from '@assets/Picture3_1762379573049.png';

export interface PharmacyBrand {
  name: string;
  keywords: string[];
  iconUrl?: string;
  iconSize?: { width: number; height: number };
}

const pharmacyBrands: PharmacyBrand[] = [
  {
    name: 'Shoppers Drug Mart',
    keywords: ['shoppers', 'shoppers drug mart', 'sdm', 'pharmaprix'],
    iconUrl: shoppersDrugMartLogo,
    iconSize: { width: 28, height: 24 } // Smaller horizontally
  },
  {
    name: 'DRUGStore Pharmacy',
    keywords: ['drugstore pharmacy'],
    iconUrl: loblawsLogo,
    iconSize: { width: 50, height: 18 }
  },
  {
    name: 'T&T Supermarket',
    keywords: ['t&t', 't & t'],
    iconUrl: ttLogo,
    iconSize: { width: 32, height: 32 } // Same as senior home/pharmachoice
  },
  {
    name: 'Rexall',
    keywords: ['rexall'],
    iconUrl: rexallLogo,
    iconSize: { width: 44, height: 17 } // Slightly smaller
  },
  {
    name: 'Pharmasave',
    keywords: ['pharmasave'],
    iconUrl: pharmasaveLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'London Drugs',
    keywords: ['london drugs'],
    iconUrl: londonDrugsLogo,
    iconSize: { width: 50, height: 18 } // Reduced height
  },
  {
    name: 'Costco Pharmacy',
    keywords: ['costco'],
    iconUrl: costcoLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Safeway',
    keywords: ['safeway'],
    iconUrl: safewayLogo,
    iconSize: { width: 28, height: 24 } // Same size as Shoppers
  },
  {
    name: 'Sobeys',
    keywords: ['sobeys', 'sobeys pharmacy'],
    iconUrl: sobeysLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Metro',
    keywords: ['metro', 'metro pharmacy'],
    iconUrl: metroLogo,
    iconSize: { width: 52, height: 16 } // Reduced height
  },
  {
    name: 'Loblaws',
    keywords: ['loblaws', 'loblaw', 'loblaws pharmacy', 'loblaw pharmacy'],
    iconUrl: loblawsLogo,
    iconSize: { width: 50, height: 18 } // Smaller vertically
  },
  {
    name: 'No Frills',
    keywords: ['no frills', 'nofrills', 'no frills pharmacy'],
    iconUrl: noFrillsLogo,
    iconSize: { width: 66, height: 57 } // Even bigger
  },
  {
    name: 'FreshCo',
    keywords: ['freshco', 'fresh co', 'freshco pharmacy'],
    iconUrl: freshcoLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Fortinos',
    keywords: ['fortinos', 'fortinos pharmacy'],
    iconUrl: fortinosLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Zehrs',
    keywords: ['zehrs', 'zehrs pharmacy'],
    iconUrl: zehrsLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Your Independent Grocer',
    keywords: ['independent grocer', 'your independent grocer', 'independent grocer pharmacy'],
    iconUrl: independentGrocerLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Save On Foods',
    keywords: ['save on foods', 'save-on-foods', 'saveonfoods', 'save on foods pharmacy'],
    iconUrl: saveOnFoodsLogo,
    iconSize: { width: 40, height: 32 } // Larger size for visibility
  },
  {
    name: 'Co-op',
    keywords: ['co-op', 'coop', 'co op'],
    iconUrl: coopLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'IDA',
    keywords: ['ida', 'i.d.a'],
    iconUrl: idaLogo,
    iconSize: { width: 40, height: 40 } // Keep original size
  },
  {
    name: 'Guardian',
    keywords: ['guardian'],
    iconUrl: guardianLogo,
    iconSize: { width: 56, height: 20 } // Reduced height
  },
  {
    name: 'Remedy\'s Rx',
    keywords: ['remedy', 'remedys', 'remedy\'s rx', 'remedysrx'],
    iconUrl: remedysRxLogo,
    iconSize: { width: 52, height: 18 } // Reduced height
  },
  {
    name: 'PharmaChoice',
    keywords: ['pharmachoice', 'pharma choice'],
    iconUrl: pharmachoiceLogo,
    iconSize: { width: 32, height: 32 } // Square sizing
  },
  {
    name: 'Medicine Shoppe',
    keywords: ['medicine shoppe'],
    iconUrl: medicineShoppeLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'People\'s Drug Mart',
    keywords: ['peoples drug mart', 'people\'s drug mart'],
    iconUrl: peoplesDrugMartLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Value Drug Mart',
    keywords: ['value drug mart'],
    iconUrl: valueDrugMartLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Jean Coutu',
    keywords: ['jean coutu', 'jeancoutu'],
    iconUrl: jeanCoutuLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Proxim',
    keywords: ['proxim'],
    iconUrl: proximLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Uniprix',
    keywords: ['uniprix'],
    iconUrl: uniprixLogo,
    iconSize: { width: 24, height: 24 } // Square size
  },
  {
    name: 'Familiprix',
    keywords: ['familiprix'],
    iconUrl: familiprixLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Brunet',
    keywords: ['brunet'],
    iconUrl: brunnetLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Maxi',
    keywords: ['maxi', 'maxi pharmacy'],
    iconUrl: maxiLogo,
    iconSize: { width: 32, height: 24 } // Reduced height
  },
  {
    name: 'Walmart',
    keywords: ['walmart', 'walmart pharmacy'],
    iconUrl: walmartLogo,
    iconSize: { width: 60, height: 20 } // Walmart logo - bigger horizontally
  },
  {
    name: 'Valu-mart',
    keywords: ['valu-mart', 'valumart', 'valu mart'],
    iconUrl: valuMartLogo,
    iconSize: { width: 60, height: 20 } // Similar to Walmart sizing
  },
  {
    name: 'Extra Foods',
    keywords: ['extra foods', 'extrafoods'],
    iconUrl: extraFoodsLogo,
    iconSize: { width: 60, height: 20 } // Similar to Walmart sizing
  },
  {
    name: 'Real Canadian Superstore',
    keywords: ['real canadian superstore', 'superstore', 'canadian superstore'],
    iconUrl: realCanadianSuperstoreLogo,
    iconSize: { width: 60, height: 20 } // Similar to Walmart sizing
  }
];

// Custom icon for independent pharmacies
const independentPharmacyIcon = independentPharmacyImage;

export function getPharmacyIcon(pharmacyName: string, website?: string): { url: string; width: number; height: number } {
  const lowerName = pharmacyName.toLowerCase();
  
  // First check name for brand keywords
  let brand = pharmacyBrands.find(b => 
    b.keywords.some(keyword => lowerName.includes(keyword.toLowerCase()))
  );
  
  // If no brand found by name, check website URL for PharmaChoice as backup
  if (!brand && website) {
    const lowerWebsite = website.toLowerCase();
    if (lowerWebsite.includes('pharmachoice')) {
      brand = pharmacyBrands.find(b => b.name === 'PharmaChoice');
    }
  }
  
  if (brand && brand.iconUrl) {
    // Use custom size if defined (for rectangular logos), otherwise default to smaller size
    const size = brand.iconSize || { width: 32, height: 24 };
    return { url: brand.iconUrl, ...size };
  }
  
  // Independent pharmacy: custom red pill icon (perfect circle)
  return { url: independentPharmacyIcon, width: 14, height: 12 };
}

export function isIndependentPharmacy(pharmacyName: string, website?: string): boolean {
  const lowerName = pharmacyName.toLowerCase();
  
  // Check name for brand keywords
  const foundInName = pharmacyBrands.some(b => 
    b.keywords.some(keyword => lowerName.includes(keyword.toLowerCase()))
  );
  
  if (foundInName) return false;
  
  // Check website for PharmaChoice as backup
  if (website && website.toLowerCase().includes('pharmachoice')) {
    return false;
  }
  
  return true;
}

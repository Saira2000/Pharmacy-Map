import { X, Star, MapPin, ExternalLink, EyeOff } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export interface GroceryInfo {
  name: string;
  address: string;
  rating?: number;
  distance?: number;
  placeId: string;
  lat: number;
  lng: number;
}

interface GroceryInfoCardProps {
  grocery: GroceryInfo;
  onClose: () => void;
  onRemove?: (placeId: string) => void;
}

export default function GroceryInfoCard({ grocery, onClose, onRemove }: GroceryInfoCardProps) {
  const handleDirections = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${grocery.lat},${grocery.lng}&destination_place_id=${grocery.placeId}`;
    window.open(url, '_blank');
  };

  const handleRemove = () => {
    if (onRemove) {
      onRemove(grocery.placeId);
    }
  };

  return (
    <Card className="p-4 shadow-2xl max-w-sm relative" data-testid={`card-grocery-${grocery.placeId}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={onClose}
        className="absolute top-2 right-2"
        data-testid="button-close-info"
      >
        <X className="w-4 h-4" />
      </Button>

      <div className="space-y-3">
        <div>
          <h3 className="text-base font-semibold pr-8 line-clamp-2" data-testid="text-grocery-name">
            {grocery.name}
          </h3>
          {grocery.rating && (
            <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              <span data-testid="text-grocery-rating">{grocery.rating.toFixed(1)}</span>
            </div>
          )}
        </div>

        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <p className="leading-relaxed" data-testid="text-grocery-address">{grocery.address}</p>
        </div>

        {grocery.distance !== undefined && (
          <div className="text-sm text-muted-foreground">
            <span className="font-medium">Distance: </span>
            <span data-testid="text-grocery-distance">
              {grocery.distance >= 1000
                ? `${(grocery.distance / 1000).toFixed(1)} km`
                : `${grocery.distance} m`}
            </span>
          </div>
        )}

        <div className="flex gap-2 mt-4">
          <Button 
            onClick={handleDirections}
            className="flex-1"
            data-testid="button-directions"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Directions
          </Button>
          {onRemove && (
            <Button
              variant="outline"
              size="icon"
              onClick={handleRemove}
              data-testid="button-hide-grocery"
              title="Hide this grocery store"
            >
              <EyeOff className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}

import { MapPin } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface LocationDisplayProps {
  city: string;
  province: string;
  town?: string;
}

export default function LocationDisplay({ city, province, town }: LocationDisplayProps) {
  return (
    <Card className="px-4 py-2 shadow-md" data-testid="card-location-display">
      <div className="flex items-center gap-2">
        <MapPin className="w-4 h-4 text-muted-foreground" />
        <div className="text-sm font-medium">
          {town && <span className="text-muted-foreground">{town}, </span>}
          <span>{city}</span>
          {province && <span className="text-muted-foreground">, {province}</span>}
        </div>
      </div>
    </Card>
  );
}

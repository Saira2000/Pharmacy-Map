import { X, Star, MapPin, ExternalLink, EyeOff, Eye } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getPrescriptionCount, formatPrescriptionCount } from '@/utils/prescriptionCounts';

export interface PharmacyInfo {
  name: string;
  address: string;
  rating?: number;
  distance?: number;
  placeId: string;
  icon?: string;
  lat: number;
  lng: number;
  displayLat?: number;
  displayLng?: number;
  rank?: string | number;
  province?: string;
  hasAdjacentClinic?: boolean;
  website?: string;
}

interface PharmacyInfoCardProps {
  pharmacy: PharmacyInfo;
  onClose: () => void;
  onRemove?: (placeId: string) => void;
  onToggleRxCount?: (placeId: string) => void;
  isRxCountHidden?: boolean;
}

export default function PharmacyInfoCard({ pharmacy, onClose, onRemove, onToggleRxCount, isRxCountHidden }: PharmacyInfoCardProps) {
  const handleDirections = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${pharmacy.lat},${pharmacy.lng}&destination_place_id=${pharmacy.placeId}`;
    window.open(url, '_blank');
  };

  const handleRemove = () => {
    if (onRemove) {
      onRemove(pharmacy.placeId);
    }
  };

  const handleToggleRxCount = () => {
    if (onToggleRxCount) {
      onToggleRxCount(pharmacy.placeId);
    }
  };

  // Get prescription count based on province and rank
  const prescriptionCount = pharmacy.rank && pharmacy.province
    ? getPrescriptionCount(pharmacy.province, pharmacy.rank)
    : null;

  return (
    <Card className="p-4 shadow-2xl max-w-sm relative" data-testid={`card-pharmacy-${pharmacy.placeId}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={onClose}
        className="absolute top-2 right-2"
        data-testid="button-close-info"
      >
        <X className="w-4 h-4" />
      </Button>

      <div className="space-y-3">
        <div>
          <h3 className="text-base font-semibold pr-8 line-clamp-2" data-testid="text-pharmacy-name">
            {pharmacy.name}
          </h3>
        </div>

        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <p className="line-clamp-2" data-testid="text-pharmacy-address">{pharmacy.address}</p>
        </div>

        {pharmacy.rating && (
          <div className="flex items-center gap-2 text-sm">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="font-medium" data-testid="text-pharmacy-rating">{pharmacy.rating.toFixed(1)}</span>
            </div>
          </div>
        )}

        {pharmacy.distance !== undefined && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span data-testid="text-pharmacy-distance">
              {pharmacy.distance >= 1000 
                ? `${(pharmacy.distance / 1000).toFixed(1)} km away`
                : `${Math.round(pharmacy.distance)} m away`
              }
            </span>
          </div>
        )}

        {pharmacy.rank !== undefined && pharmacy.rank !== null && (
          <div className="flex items-center gap-2 text-sm flex-wrap">
            <div className="flex items-center gap-1 px-2 py-1 bg-primary/10 rounded-md">
              <span className="text-xs font-medium text-muted-foreground">Rank:</span>
              <span className="font-semibold text-primary" data-testid="text-pharmacy-rank">{pharmacy.rank}</span>
            </div>
            {prescriptionCount !== null && (
              <div className="flex items-center gap-1 px-2 py-1 bg-secondary/30 rounded-md">
                <span className="font-semibold text-secondary-foreground" data-testid="text-pharmacy-rx-count">
                  {formatPrescriptionCount(prescriptionCount)}
                </span>
              </div>
            )}
          </div>
        )}

        {pharmacy.hasAdjacentClinic && (
          <div className="flex items-center gap-2 text-sm">
            <div className="flex items-center gap-1 px-2 py-1 bg-blue-100 dark:bg-blue-900/30 rounded-md">
              <span className="text-xs font-medium text-blue-700 dark:text-blue-300" data-testid="text-adjacent-clinic">
                Adjacent clinic
              </span>
            </div>
          </div>
        )}

        <div className="flex gap-2 mt-4">
          <Button 
            onClick={handleDirections}
            className="flex-1 rounded-lg"
            data-testid="button-get-directions"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Get Directions
          </Button>
          {onToggleRxCount && prescriptionCount !== null && (
            <Button 
              onClick={handleToggleRxCount}
              variant="outline"
              className="rounded-lg"
              title={isRxCountHidden ? "Show Rx count on map" : "Hide Rx count on map"}
              data-testid="button-toggle-rx-count"
            >
              {isRxCountHidden ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            </Button>
          )}
          {onRemove && (
            <Button 
              onClick={handleRemove}
              variant="outline"
              className="rounded-lg"
              data-testid="button-remove-pharmacy"
            >
              <EyeOff className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}

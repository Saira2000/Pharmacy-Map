import SearchBar from '../SearchBar';

export default function SearchBarExample() {
  return (
    <div className="w-full h-screen bg-background p-8">
      <SearchBar
        onSearch={(address) => console.log('Search for:', address)}
        onClear={() => console.log('Clear search')}
        isLoading={false}
      />
    </div>
  );
}

import LoadingSpinner from '../LoadingSpinner';

export default function LoadingSpinnerExample() {
  return (
    <div className="w-full h-screen bg-background flex items-center justify-center">
      <LoadingSpinner message="Finding pharmacies..." />
    </div>
  );
}

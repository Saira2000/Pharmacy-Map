import { useState } from 'react';
import RadiusControl from '../RadiusControl';

export default function RadiusControlExample() {
  const [radius, setRadius] = useState(1000);

  return (
    <div className="w-full h-screen bg-background p-8 flex items-center justify-center">
      <RadiusControl
        radius={radius}
        onRadiusChange={(newRadius) => {
          setRadius(newRadius);
          console.log('Radius changed to:', newRadius);
        }}
      />
    </div>
  );
}

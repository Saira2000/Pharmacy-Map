import PharmacyInfoCard from '../PharmacyInfoCard';

export default function PharmacyInfoCardExample() {
  const mockPharmacy = {
    name: "Shoppers Drug Mart",
    address: "5628 4 St NW, Calgary, AB T2K 1B2, Canada",
    rating: 4.2,
    distance: 850,
    placeId: "ChIJexample123",
    lat: 51.0447,
    lng: -114.0719
  };

  return (
    <div className="w-full h-screen bg-background p-8 flex items-center justify-center">
      <PharmacyInfoCard
        pharmacy={mockPharmacy}
        onClose={() => console.log('Close card')}
      />
    </div>
  );
}

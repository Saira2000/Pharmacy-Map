import { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface SearchBarProps {
  onSearch: (address: string) => void;
  onClear: () => void;
  placeholder?: string;
  isLoading?: boolean;
  value?: string;
}

export default function SearchBar({ 
  onSearch, 
  onClear, 
  placeholder = "Enter an address to find nearby pharmacies...",
  isLoading = false,
  value 
}: SearchBarProps) {
  const [searchValue, setSearchValue] = useState('');

  useEffect(() => {
    if (value !== undefined) {
      setSearchValue(value);
    }
  }, [value]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim()) {
      onSearch(searchValue.trim());
    }
  };

  const handleClear = () => {
    setSearchValue('');
    onClear();
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="relative flex items-center gap-2">
        <div className="relative flex-1">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            ) : (
              <Search className="w-5 h-5" />
            )}
          </div>
          <Input
            type="text"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder={placeholder}
            className="h-12 pl-12 pr-4 text-base border-2 rounded-xl shadow-md"
            data-testid="input-address-search"
          />
        </div>
        {searchValue && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={handleClear}
            className="h-12 w-12 rounded-xl shadow-md flex-shrink-0"
            data-testid="button-clear-search"
          >
            <X className="w-5 h-5" />
          </Button>
        )}
      </div>
    </form>
  );
}

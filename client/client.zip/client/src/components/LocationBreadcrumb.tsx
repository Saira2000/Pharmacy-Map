import { ChevronRight } from 'lucide-react';

interface LocationBreadcrumbProps {
  city?: string;
  province?: string;
  town?: string;
  zoomLevel: number;
}

export default function LocationBreadcrumb({ city, province, town, zoomLevel }: LocationBreadcrumbProps) {
  const breadcrumbs = [];
  
  if (province || city || town) {
    breadcrumbs.push('North America');
    breadcrumbs.push('Canada');
  }
  
  if (province) {
    // Convert province code to full name
    const provinceNames: { [key: string]: string } = {
      'AB': 'Alberta',
      'BC': 'British Columbia',
      'MB': 'Manitoba',
      'NB': 'New Brunswick',
      'NL': 'Newfoundland and Labrador',
      'NT': 'Northwest Territories',
      'NS': 'Nova Scotia',
      'NU': 'Nunavut',
      'ON': 'Ontario',
      'PE': 'Prince Edward Island',
      'QC': 'Quebec',
      'SK': 'Saskatchewan',
      'YT': 'Yukon'
    };
    breadcrumbs.push(provinceNames[province] || province);
  }
  
  if (city) {
    breadcrumbs.push(city);
  }
  
  if (town && town !== city) {
    breadcrumbs.push(town);
  }

  if (breadcrumbs.length === 0) return null;

  return (
    <div className="bg-muted border-b px-4 py-2 flex items-center justify-between" data-testid="location-breadcrumb">
      <div className="flex items-center gap-1 text-sm text-muted-foreground flex-wrap">
        {breadcrumbs.map((crumb, index) => (
          <div key={index} className="flex items-center gap-1">
            <span className={index === breadcrumbs.length - 1 ? 'font-medium text-foreground' : ''}>
              {crumb}
            </span>
            {index < breadcrumbs.length - 1 && (
              <ChevronRight className="w-4 h-4" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface RadiusControlProps {
  radius: number;
  onRadiusChange: (radius: number) => void;
  minRadius?: number;
  maxRadius?: number;
}

export default function RadiusControl({ 
  radius, 
  onRadiusChange,
  minRadius = 500,
  maxRadius = 5000
}: RadiusControlProps) {
  const presets = [500, 1000, 2000, 5000];

  return (
    <Card className="p-4 shadow-lg max-w-xs" data-testid="card-radius-control">
      <div className="space-y-4">
        <div className="text-center">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">
            Search Radius
          </div>
          <div className="text-2xl font-bold text-foreground">
            {radius >= 1000 ? `${(radius / 1000).toFixed(1)}km` : `${radius}m`}
          </div>
        </div>

        <div className="px-2">
          <Slider
            value={[radius]}
            onValueChange={([value]) => onRadiusChange(value)}
            min={minRadius}
            max={maxRadius}
            step={100}
            className="w-full"
            data-testid="slider-radius"
          />
        </div>

        <div className="flex gap-2 flex-wrap">
          {presets.map((preset) => (
            <Button
              key={preset}
              variant={radius === preset ? "default" : "outline"}
              size="sm"
              onClick={() => onRadiusChange(preset)}
              className="rounded-full text-xs flex-1"
              data-testid={`button-preset-${preset}`}
            >
              {preset >= 1000 ? `${preset / 1000}km` : `${preset}m`}
            </Button>
          ))}
        </div>
      </div>
    </Card>
  );
}

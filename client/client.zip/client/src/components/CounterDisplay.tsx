import { Card } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface CounterDisplayProps {
  icon: LucideIcon;
  label: string;
  count: number;
  testId?: string;
}

export default function CounterDisplay({ icon: Icon, label, count, testId }: CounterDisplayProps) {
  return (
    <Card className="px-4 py-2 shadow-md" data-testid={testId}>
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 text-primary" />
        <div className="flex items-baseline gap-1.5">
          <span className="text-xl font-bold">{count}</span>
          <span className="text-xs text-muted-foreground uppercase tracking-wide">{label}</span>
        </div>
      </div>
    </Card>
  );
}

// Cache bust: v3.16
import { useState, useCallback, useRef, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import SearchBar from '@/components/SearchBar';
import RadiusControl from '@/components/RadiusControl';
import PharmacyInfoCard, { type PharmacyInfo } from '@/components/PharmacyInfoCard';
import SeniorHomeInfoCard, { type SeniorHomeInfo as SeniorHomeInfoCardType } from '@/components/SeniorHomeInfoCard';
import GroceryInfoCard from '@/components/GroceryInfoCard';
import LocationDisplay from '@/components/LocationDisplay';
import CounterDisplay from '@/components/CounterDisplay';
import LoadingSpinner from '@/components/LoadingSpinner';
import LocationBreadcrumb from '@/components/LocationBreadcrumb';
import { Button } from '@/components/ui/button';
import { RotateCcw, Plus, Minus, Pill, ShoppingCart, Eye, Home, Maximize2, Minimize2, ChevronDown, Check } from 'lucide-react';
import { getPharmacyIcon, isIndependentPharmacy } from '@/utils/pharmacyIcons';
import { loadPharmacyRankings, findRankByAddress, parseUploadedRankings } from '@/utils/parseRankings';
import { getPrescriptionCount } from '@/utils/prescriptionCounts';
import seniorHomeIcon from '@assets/image_1764772177244.png';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";

// Loblaw Companies Limited brands (always show logo, no cart icon, no Rx count)
const LOBLAW_BRANDS = [
  'shoppers drug mart',
  'shoppers',
  'sdm',
  'pharmaprix',
  'loblaws',
  'no frills',
  'real canadian superstore',
  'superstore',
  'zehrs',
  'fortinos',
  'valu-mart',
  'valumart',
  'provigo',
  'your independent grocer',
  'independent grocer',
  'maxi',
  'extra foods',
  'drugstore pharmacy',
  't&t',
  't & t'
];

export interface GroceryInfo {
  name: string;
  address: string;
  rating?: number;
  placeId: string;
  icon?: string;
  lat: number;
  lng: number;
  distance: number;
}

export interface SeniorHomeInfo {
  name: string;
  address: string;
  rating?: number;
  placeId: string;
  lat: number;
  lng: number;
  distance: number;
}

export interface LocationInfo {
  city: string;
  province: string;
  town?: string;
}

const libraries: ("places" | "geometry")[] = ["places", "geometry"];

const mapContainerStyle = {
  width: '100%',
  height: '100%'
};

const defaultCenter = {
  lat: 51.0447,
  lng: -114.0719
};

export default function PharmacyLocator() {
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [center, setCenter] = useState(defaultCenter);
  const [radius, setRadius] = useState(1000); // 1km default
  const [allPharmacies, setAllPharmacies] = useState<PharmacyInfo[]>([]); // All fetched pharmacies
  const [rawGroceries, setRawGroceries] = useState<GroceryInfo[]>([]); // Raw grocery results before deduplication
  const [groceries, setGroceries] = useState<GroceryInfo[]>([]); // Deduplicated groceries
  const [seniorHomes, setSeniorHomes] = useState<SeniorHomeInfo[]>([]);
  const [selectedPharmacy, setSelectedPharmacy] = useState<PharmacyInfo | null>(null);
  const [selectedSeniorHome, setSelectedSeniorHome] = useState<SeniorHomeInfo | null>(null);
  const [selectedGrocery, setSelectedGrocery] = useState<GroceryInfo | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchedAddress, setSearchedAddress] = useState<string | null>(null);
  const [locationInfo, setLocationInfo] = useState<LocationInfo | null>(null);
  const [headerHeight, setHeaderHeight] = useState(88);
  const [hiddenPharmacies, setHiddenPharmacies] = useState<Set<string>>(new Set());
  const [hiddenSeniorHomes, setHiddenSeniorHomes] = useState<Set<string>>(new Set());
  const [hiddenGroceries, setHiddenGroceries] = useState<Set<string>>(new Set());
  const [hiddenRxCounts, setHiddenRxCounts] = useState<Set<string>>(new Set());
  const [zoomLevel, setZoomLevel] = useState(11);
  const [searchedLocation, setSearchedLocation] = useState<google.maps.LatLng | null>(null);
  const [rankingsMap, setRankingsMap] = useState<Map<string, string | number>>(new Map());
  const [isMapMaximized, setIsMapMaximized] = useState(false);
  const [showRxCounts, setShowRxCounts] = useState(true);
  const geocoderRef = useRef<google.maps.Geocoder | null>(null);
  const placesServiceRef = useRef<google.maps.places.PlacesService | null>(null);
  const headerRef = useRef<HTMLDivElement | null>(null);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
    libraries
  });

  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMap(map);
    geocoderRef.current = new google.maps.Geocoder();
    placesServiceRef.current = new google.maps.places.PlacesService(map);
    
    // Create custom scale bar with km/m display
    const scaleContainer = document.createElement('div');
    scaleContainer.style.position = 'relative';
    scaleContainer.style.margin = '10px';
    scaleContainer.style.padding = '8px';
    scaleContainer.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
    scaleContainer.style.border = '1px solid #999';
    scaleContainer.style.borderRadius = '4px';
    scaleContainer.style.fontFamily = 'Arial, sans-serif';
    scaleContainer.style.fontSize = '11px';
    scaleContainer.style.color = '#333';
    scaleContainer.style.minWidth = '80px';
    
    const scaleBar = document.createElement('div');
    scaleBar.style.height = '2px';
    scaleBar.style.backgroundColor = '#333';
    scaleBar.style.marginBottom = '2px';
    scaleBar.style.width = '60px';
    
    const scaleLabel = document.createElement('div');
    scaleLabel.style.textAlign = 'center';
    scaleLabel.style.fontSize = '11px';
    scaleLabel.style.fontWeight = 'bold';
    
    scaleContainer.appendChild(scaleBar);
    scaleContainer.appendChild(scaleLabel);
    
    const updateScale = () => {
      if (!map) return;
      
      const bounds = map.getBounds();
      if (!bounds) return;
      
      const center = map.getCenter();
      if (!center) return;

      const lat = center.lat();
      const zoom = map.getZoom() || 0;
      
      // 156543.03392 is the resolution at zoom 0 at the equator (meters/pixel)
      const resolution = 156543.03392 * Math.cos(lat * Math.PI / 180) / Math.pow(2, zoom);
      
      // Use fixed scale width logic: 1 pixel on the map at zoom z is (156543.03392 * cos(lat) / 2^z) meters.
      // However, we want the scale bar to accurately reflect the Google Maps distance scale.
      // To ensure accuracy, we use the standard formula and a fixed pixel width.
      const actualWidthPx = 150; 
      const distance = actualWidthPx * resolution;
      
      console.log(`[SCALE DEBUG] Zoom: ${zoom}, Lat: ${lat.toFixed(4)}, Res: ${resolution.toFixed(4)}, Dist: ${distance}m, Width: ${actualWidthPx.toFixed(2)}px`);

      scaleBar.style.width = `${actualWidthPx}px`;

      if (distance >= 1000) {
        scaleLabel.textContent = `${(distance / 1000).toFixed(2)} km`;
      } else {
        scaleLabel.textContent = `${Math.round(distance)} m`;
      }
    };
    
    map.controls[google.maps.ControlPosition.TOP_RIGHT].push(scaleContainer);
    updateScale();
    
    // Update scale on zoom and center change
    map.addListener('zoom_changed', () => {
      const zoom = map.getZoom();
      if (zoom !== undefined) {
        setZoomLevel(zoom);
      }
      updateScale();
    });
    
    map.addListener('center_changed', updateScale);
  }, []);

  const onMapUnmount = useCallback(() => {
    setMap(null);
  }, []);

  useEffect(() => {
    if (headerRef.current) {
      const observer = new ResizeObserver(() => {
        if (headerRef.current) {
          setHeaderHeight(headerRef.current.offsetHeight);
        }
      });
      observer.observe(headerRef.current);
      return () => observer.disconnect();
    }
  }, []);

  // Load pharmacy rankings on mount
  useEffect(() => {
    loadPharmacyRankings().then((rankings) => {
      setRankingsMap(rankings);
    });
  }, []);

  // Merge pharmacies and groceries at same location: use grocery name with pharmacy details
  useEffect(() => {
    console.log(`[MERGE DEBUG] Effect triggered - Pharmacies: ${allPharmacies.length}, Raw Groceries: ${rawGroceries.length}`);
    
    if (rawGroceries.length === 0) {
      setGroceries([]);
      return;
    }

    if (allPharmacies.length === 0) {
      // No pharmacies yet, show all groceries
      setGroceries(rawGroceries);
      return;
    }

    // Track which groceries have matching pharmacies
    const groceriesWithPharmacies = new Set<string>();
    let hasChanges = false;

    // Update pharmacy names to use grocery names when at same location
    const updatedPharmacies = allPharmacies.map((pharmacy) => {
      const pharmacyLocation = new google.maps.LatLng(pharmacy.lat, pharmacy.lng);
      
      // Find matching grocery at same location
      const matchingGrocery = rawGroceries.find((grocery) => {
        const groceryLocation = new google.maps.LatLng(grocery.lat, grocery.lng);
        const distance = google.maps.geometry.spherical.computeDistanceBetween(
          groceryLocation,
          pharmacyLocation
        );
        
        if (distance <= 50) {
          console.log(`[MERGE DEBUG] Found potential match within 50m (${Math.round(distance)}m):`);
          console.log(`  Pharmacy: "${pharmacy.name}" at ${pharmacy.address}`);
          console.log(`  Grocery: "${grocery.name}" at ${grocery.address}`);
        }
        
        return distance <= 50; // Within 50 meters
      });

      if (matchingGrocery) {
        // Mark this grocery as having a pharmacy
        groceriesWithPharmacies.add(matchingGrocery.placeId);
        
        // Only update if names are different (prevent infinite loop)
        if (pharmacy.name !== matchingGrocery.name) {
          hasChanges = true;
          console.log(`✅ MERGED: Using "${matchingGrocery.name}" instead of "${pharmacy.name}"`);
          return {
            ...pharmacy,
            name: matchingGrocery.name // Use the grocery name people know
          };
        } else {
          console.log(`⚠️ Already merged: "${pharmacy.name}" (names match)`);
        }
      }

      return pharmacy;
    });

    // Only update pharmacies if names actually changed
    if (hasChanges) {
      console.log(`[MERGE DEBUG] Updating pharmacy state with ${updatedPharmacies.length} pharmacies`);
      setAllPharmacies(updatedPharmacies);
    } else {
      console.log(`[MERGE DEBUG] No name changes needed`);
    }

    // Filter out groceries that have pharmacies (already shown as pharmacy markers)
    const deduplicatedGroceries = rawGroceries.filter((grocery) => {
      return !groceriesWithPharmacies.has(grocery.placeId);
    });

    const removedCount = rawGroceries.length - deduplicatedGroceries.length;
    if (removedCount > 0) {
      console.log(`[MERGE DEBUG] Removed ${removedCount} grocery markers that are shown as pharmacies`);
    }

    setGroceries(deduplicatedGroceries);
  }, [rawGroceries, allPharmacies]);

  // Collision detection and marker offset algorithm
  const applyCollisionDetection = useCallback((pharmacies: PharmacyInfo[]): PharmacyInfo[] => {
    if (pharmacies.length === 0) return pharmacies;

    // Minimum distance in meters to consider as collision (approximately 15 meters)
    const COLLISION_THRESHOLD = 15;
    
    // Offset distance in meters (small offset for visual separation)
    const OFFSET_DISTANCE = 8;

    // Create a copy to avoid mutating original array
    const result = [...pharmacies];

    // For each pharmacy, check for collisions with others
    for (let i = 0; i < result.length; i++) {
      const current = result[i];
      let hasCollision = false;
      let offsetAngle = 0;
      let collisionCount = 0;

      for (let j = 0; j < result.length; j++) {
        if (i === j) continue;

        const other = result[j];
        const distance = google.maps.geometry?.spherical.computeDistanceBetween(
          new google.maps.LatLng(current.lat, current.lng),
          new google.maps.LatLng(other.lat, other.lng)
        );

        if (distance < COLLISION_THRESHOLD) {
          hasCollision = true;
          collisionCount++;
        }
      }

      if (hasCollision) {
        // Apply offset in a circular pattern based on index
        const angle = (i * (Math.PI * 2)) / Math.max(collisionCount + 1, 4);
        
        // Convert offset distance to lat/lng degrees (rough approximation)
        // 1 degree latitude ≈ 111,320 meters
        const offsetLat = (OFFSET_DISTANCE * Math.cos(angle)) / 111320;
        const offsetLng = (OFFSET_DISTANCE * Math.sin(angle)) / (111320 * Math.cos(current.lat * Math.PI / 180));

        // Set display coordinates with offset, keep original coordinates
        result[i] = {
          ...current,
          displayLat: current.lat + offsetLat,
          displayLng: current.lng + offsetLng
        };
      } else {
        // No collision, display at original position
        result[i] = {
          ...current,
          displayLat: current.lat,
          displayLng: current.lng
        };
      }
    }

    return result;
  }, []);

  const searchPharmacies = useCallback((location: google.maps.LatLng) => {
    console.log(`🔵 searchPharmacies CALLED with location: ${location.lat()}, ${location.lng()}`);
    
    if (!placesServiceRef.current) {
      console.error('❌ placesServiceRef is not initialized!');
      return;
    }

    const allResults: google.maps.places.PlaceResult[] = [];
    let pageCount = 0;
    const maxPages = 3; // Google allows up to 3 pages (60 results max)

    const fetchPage = (request: google.maps.places.PlaceSearchRequest) => {
      console.log(`🔵 fetchPage CALLED - requesting pharmacy search at radius: ${request.radius}m`);
      
      placesServiceRef.current!.nearbySearch(request, (results, status, pagination) => {
        console.log(`🟢 Google API Callback fired! Status: ${status}, Results: ${results?.length || 0}`);
        
        if ((status === google.maps.places.PlacesServiceStatus.OK || status === google.maps.places.PlacesServiceStatus.ZERO_RESULTS) && results) {
          allResults.push(...results);
          pageCount++;
          
          console.log(`Page ${pageCount}: Found ${results.length} results (Total: ${allResults.length})`);

          // Check if there's a next page and we haven't hit the limit
          if (pagination?.hasNextPage && pageCount < maxPages) {
            // Google requires a short delay before fetching the next page
            console.log(`🔵 Fetching next page in 2 seconds...`);
            setTimeout(() => {
              pagination.nextPage();
            }, 2000);
          } else {
            // All pages fetched, now process the results
            console.log(`✅ All pages fetched. Calling processResults with ${allResults.length} total results`);
            processResults(allResults, location);
          }
        } else {
          console.error('❌ Pharmacy search failed with status:', status);
          const statusStr = String(status);
          if (statusStr.includes('DENIED') || statusStr.includes('PERMISSION')) {
            alert('⚠️ Places API Not Enabled\n\nYour Google Maps API key needs the Places API enabled.\n\nSteps to fix:\n1. Go to console.cloud.google.com\n2. Select your project\n3. Go to "APIs & Services" > "Library"\n4. Search for "Places API" (not "Places API New")\n5. Click "Enable"\n6. Wait 1-2 minutes, then refresh this page\n\nNote: Make sure you enable the legacy "Places API", not the new version.');
          }
          console.log(`⚠️ Calling processResults anyway with ${allResults.length} results`);
          processResults(allResults, location);
        }
      });
    };

    const processResults = (results: google.maps.places.PlaceResult[], centerLocation: google.maps.LatLng) => {
      console.log(`🔍 NEW FILTERING CODE IS RUNNING! Total raw results from Google: ${results.length}`);
      
      // Log all raw results from Google (only in development)
      if (import.meta.env.DEV) {
        console.log('=== RAW GOOGLE MAPS RESULTS (BEFORE FILTERING) ===');
        results.forEach((place, idx) => {
          console.log(`  [${idx + 1}] ${place.name} - ${place.vicinity}`);
        });
        console.log('====================================================');
      }
      
      // Remove duplicates and filter out non-pharmacies
      const uniquePlaces = new Map<string, google.maps.places.PlaceResult>();
      results.forEach(place => {
        if (place.place_id && !uniquePlaces.has(place.place_id)) {
          const name = (place.name || '').toLowerCase();
          
          // Filter out clinics (unless they're major pharmacy chains with clinics)
          const isClinic = name.includes('clinic') && !name.includes('shoppers') && !name.includes('rexall') && !name.includes('guardian') && !name.includes('pharma') && !name.includes('ida');
          const isMedicalCentre = (name.includes('medical centre') || name.includes('medical center')) && !name.includes('pharmacy') && !name.includes('ida');
          
          // Filter out grocery stores, markets, and other non-pharmacy businesses
          const isGroceryStore = (
            (name.includes('marché') || name.includes('épicerie') ||
             name.includes('supermarket') || name.includes('grocery')) &&
            !name.includes('pharma') && !name.includes('drug') && !name.includes('rx') && 
            !name.includes('apotheke') && !name.includes('apotek') && !name.includes('ida') &&
            !name.includes('convenience') && !name.includes('dépanneur') &&
            !name.includes('medicine shoppe') && !name.includes('pharmasave') &&
            !name.includes('wellness pharmacy') && !name.includes('biopro')
          );
          
          // Comprehensive list of pharmacy indicators (works across Canada and internationally)
          const isPharmacy = 
            // Generic pharmacy terms
            name.includes('pharma') || name.includes('drug') || name.includes('rx') || 
            name.includes('apotheke') || name.includes('apotek') || name.includes('apothicaire') ||
            name.includes('dispensary') || name.includes('chemist') || name.includes('pharmacie') ||
            // Major Canadian chains
            name.includes('shoppers') || name.includes('rexall') || name.includes('guardian') ||
            name.includes('uniprix') || name.includes('proxim') || name.includes('jean coutu') ||
            name.includes('brunet') || name.includes('familiprix') || name.includes('pharmaprix') ||
            name.includes('pharmasave') || name.includes('london drugs') || name.includes('ida') ||
            name.includes('costco') || name.includes('walmart') || 
            name.includes('safeway') || name.includes('sobeys') ||
            name.includes('freshco') || name.includes('thrifty') ||
            name.includes('metro') || name.includes('loblaws') ||
            name.includes('save-on-foods') || name.includes('save on foods') ||
            name.includes('medicine shoppe') || name.includes('pharmachoice') ||
            name.includes("remedy's rx") || name.includes('remedys rx') ||
            name.includes('value drug mart') || name.includes('co-op') ||
            name.includes('wellness pharmacy') || name.includes('biopro') || 
            name.includes('macdonald') || name.includes('laurel prescriptions') ||
            name.includes('prescriptions') || name.includes('apothecary') ||
            name.includes('health centre pharmacy') || name.includes('medical pharmacy') ||
            name.includes('community pharmacy');
          
          if (isPharmacy && !isClinic && !isMedicalCentre && !isGroceryStore) {
            uniquePlaces.set(place.place_id, place);
          } else if (import.meta.env.DEV) {
            console.log(`❌ Filtered out: ${place.name} (clinic=${isClinic}, medical=${isMedicalCentre}, grocery=${isGroceryStore}, pharmacy=${isPharmacy})`);
          }
        }
      });

      // Build initial pharmacy list
      const initialPharmacyList: PharmacyInfo[] = Array.from(uniquePlaces.values()).map((place) => {
        const lat = place.geometry?.location?.lat() || 0;
        const lng = place.geometry?.location?.lng() || 0;
        
        const distance = google.maps.geometry.spherical.computeDistanceBetween(
          centerLocation,
          new google.maps.LatLng(lat, lng)
        );

        const pharmacyName = place.name || 'Unknown Pharmacy';
        const customIcon = getPharmacyIcon(pharmacyName);

        return {
          name: pharmacyName,
          address: place.vicinity || '',
          rating: place.rating,
          placeId: place.place_id || '',
          icon: customIcon.url,
          lat,
          lng,
          distance: Math.round(distance)
        };
      });

      console.log(`After filtering: ${initialPharmacyList.length} unique pharmacies`);
      
      // Log all pharmacies found
      initialPharmacyList.forEach((p, idx) => {
        console.log(`  [${idx + 1}] ${p.name} - ${p.address} (${p.distance}m away)`);
      });

      // Find independent pharmacies that might be PharmaChoice
      const independentPharmacies = initialPharmacyList.filter(p => isIndependentPharmacy(p.name));
      console.log(`🔍 PHARMACHOICE CHECK: Found ${independentPharmacies.length} independent pharmacies to check`);
      independentPharmacies.forEach((p, idx) => {
        console.log(`  Independent [${idx + 1}]: ${p.name} - ${p.address}`);
      });

      // If there are independent pharmacies, check their websites for PharmaChoice
      if (independentPharmacies.length > 0 && placesServiceRef.current) {
        let websiteChecksCompleted = 0;
        const pharmacyUpdates = new Map<string, string>(); // placeId -> website

        independentPharmacies.forEach((pharmacy) => {
          const detailsRequest: google.maps.places.PlaceDetailsRequest = {
            placeId: pharmacy.placeId,
            fields: ['website']
          };

          placesServiceRef.current!.getDetails(detailsRequest, (placeDetails, detailsStatus) => {
            websiteChecksCompleted++;
            console.log(`📡 Website check ${websiteChecksCompleted}/${independentPharmacies.length} for: ${pharmacy.name} - Status: ${detailsStatus}`);
            
            if (detailsStatus === google.maps.places.PlacesServiceStatus.OK && placeDetails?.website) {
              const website = placeDetails.website;
              console.log(`  Website for ${pharmacy.name}: ${website}`);
              
              if (website.toLowerCase().includes('pharmachoice')) {
                console.log(`🎯 Found PharmaChoice: ${pharmacy.name} via website: ${website}`);
                pharmacyUpdates.set(pharmacy.placeId, website);
              }
            } else {
              console.log(`  No website found for ${pharmacy.name}`);
            }

            // When all website checks are done, update the pharmacy list
            if (websiteChecksCompleted === independentPharmacies.length) {
              const updatedPharmacyList = initialPharmacyList.map(p => {
                if (pharmacyUpdates.has(p.placeId)) {
                  const website = pharmacyUpdates.get(p.placeId)!;
                  const newIcon = getPharmacyIcon(p.name, website);
                  return { ...p, icon: newIcon.url, website };
                }
                return p;
              });

              // Apply collision detection to prevent overlapping markers
              const pharmaciesWithOffsets = applyCollisionDetection(updatedPharmacyList);
              console.log(`After collision detection: ${pharmaciesWithOffsets.length} pharmacies`);
              
              setAllPharmacies(pharmaciesWithOffsets);
              setIsSearching(false);
            }
          });
        });
      } else {
        // No independent pharmacies to check, proceed directly
        const pharmaciesWithOffsets = applyCollisionDetection(initialPharmacyList);
        console.log(`After collision detection: ${pharmaciesWithOffsets.length} pharmacies`);
        
        setAllPharmacies(pharmaciesWithOffsets);
        setIsSearching(false);
      }
    };

    // Prioritize pharmacies in 2km range as requested
    const request: google.maps.places.PlaceSearchRequest = {
      location,
      radius: 2000,
      type: 'pharmacy'
    };

    fetchPage(request);
  }, [applyCollisionDetection]);

  const searchGroceries = useCallback((location: google.maps.LatLng, searchRadius: number) => {
    if (!placesServiceRef.current) return;

    const request: google.maps.places.PlaceSearchRequest = {
      location,
      radius: searchRadius,
      type: 'grocery_or_supermarket'
    };

    placesServiceRef.current.nearbySearch(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && results) {
        // Filter to only include actual grocery stores or Loblaw brands
        const filteredResults = results.filter(place => {
          const name = (place.name || '').toLowerCase();
          return (
            name.includes('grocery') || 
            name.includes('épicerie') || 
            name.includes('supermarket') || 
            name.includes('marché') ||
            LOBLAW_BRANDS.some(brand => name.includes(brand))
          ) && !name.includes('convenience') && !name.includes('dépanneur');
        });

        const newGroceries: GroceryInfo[] = filteredResults.map((place) => {
          const lat = place.geometry?.location?.lat() || 0;
          const lng = place.geometry?.location?.lng() || 0;
          
          const distance = google.maps.geometry.spherical.computeDistanceBetween(
            location,
            new google.maps.LatLng(lat, lng)
          );

          return {
            name: place.name || 'Unknown Grocery',
            address: place.vicinity || '',
            rating: place.rating,
            placeId: place.place_id || '',
            icon: place.icon,
            lat,
            lng,
            distance: Math.round(distance)
          };
        });

        // Merge with existing groceries, keeping all unique ones by place_id
        setRawGroceries(prev => {
          const merged = new Map<string, GroceryInfo>();
          
          // Add all previous groceries
          prev.forEach(g => merged.set(g.placeId, g));
          
          // Add/update with new groceries
          newGroceries.forEach(g => merged.set(g.placeId, g));
          
          return Array.from(merged.values());
        });
        setIsSearching(false);
      } else {
        console.error('Grocery search failed with status:', status);
        // Don't clear existing groceries on error
        setIsSearching(false);
      }
    });
  }, []);

  const searchSeniorHomes = useCallback((location: google.maps.LatLng, searchRadius: number) => {
    if (!placesServiceRef.current) return;

    console.log(`🏥 SENIOR HOMES SEARCH: Starting search at ${location.lat()}, ${location.lng()} with radius ${searchRadius}m`);

    const request: google.maps.places.PlaceSearchRequest = {
      location,
      radius: searchRadius,
      type: 'nursing_home'
    };

    placesServiceRef.current.nearbySearch(request, (results, status) => {
      console.log(`🏥 SENIOR HOMES SEARCH CALLBACK: Status=${status}, Results count=${results?.length || 0}`);
      
      if (status === google.maps.places.PlacesServiceStatus.OK && results && results.length > 0) {
        console.log(`✅ Raw results from Google (${results.length}):`, results.map((r) => `${r.name} - ${r.vicinity}`));
        
        // Filter to ONLY genuine senior/nursing/retirement homes
        // Exclude groceries, pharmacies, restaurants, and other irrelevant places
        const filteredResults = results.filter((place) => {
          const name = (place.name || '').toLowerCase();
          const types = place.types || [];
          
          // EXCLUDE: groceries, pharmacies, restaurants, stores, etc.
          const isExcluded = (
            types.includes('grocery_or_supermarket') ||
            types.includes('pharmacy') ||
            types.includes('store') ||
            types.includes('restaurant') ||
            types.includes('food') ||
            types.includes('cafe') ||
            types.includes('hospital') ||
            types.includes('doctor') ||
            name.includes('pharmacy') ||
            name.includes('drug') ||
            name.includes('grocery') ||
            name.includes('supermarket') ||
            name.includes('walmart') ||
            name.includes('costco') ||
            name.includes('sobeys') ||
            name.includes('safeway') ||
            name.includes('save-on') ||
            name.includes('no frills') ||
            name.includes('loblaws') ||
            name.includes('shoppers')
          );
          
          if (isExcluded) {
            console.log(`  📍 "${place.name}": ❌ EXCLUDED (grocery/pharmacy/store)`);
            return false;
          }
          
          // INCLUDE: genuine senior/nursing/retirement homes
          const isGenuineSeniorHome = (
            name.includes('senior') ||
            name.includes('nursing') ||
            name.includes('retirement') ||
            name.includes('assisted living') ||
            name.includes('long term care') ||
            name.includes('long-term care') ||
            name.includes('care home') ||
            name.includes('care centre') ||
            name.includes('care center') ||
            name.includes('ltc') ||
            name.includes('elder') ||
            name.includes('aged care') ||
            name.includes('lodge') ||
            name.includes('manor') ||
            name.includes('residence') ||
            name.includes('villa') ||
            name.includes('haven') ||
            name.includes('terrace') ||
            name.includes('place') && (name.includes('senior') || name.includes('retire'))
          );
          
          console.log(`  📍 "${place.name}": ${isGenuineSeniorHome ? '✅ ACCEPTED' : '❌ FILTERED OUT'}`);
          return isGenuineSeniorHome;
        });

        console.log(`✅ After filtering: ${filteredResults.length} genuine senior homes`);
        
        const newSeniorHomes: SeniorHomeInfo[] = filteredResults.map((place) => {
          const lat = place.geometry?.location?.lat() || 0;
          const lng = place.geometry?.location?.lng() || 0;
          
          const distance = google.maps.geometry.spherical.computeDistanceBetween(
            location,
            new google.maps.LatLng(lat, lng)
          );

          console.log(`➕ Adding senior home: ${place.name} at distance ${Math.round(distance)}m`);

          return {
            name: place.name || 'Unknown Senior Home',
            address: place.vicinity || '',
            rating: place.rating,
            placeId: place.place_id || '',
            lat,
            lng,
            distance: Math.round(distance)
          };
        });

        console.log(`🏥 Total senior homes to add: ${newSeniorHomes.length}`);

        // Merge with existing senior homes, keeping all unique ones by place_id
        setSeniorHomes(prev => {
          const merged = new Map<string, SeniorHomeInfo>();
          
          // Add all previous senior homes
          prev.forEach(s => merged.set(s.placeId, s));
          
          // Add/update with new senior homes
          newSeniorHomes.forEach(s => merged.set(s.placeId, s));
          
          const final = Array.from(merged.values());
          console.log(`🏥 Final senior homes count: ${final.length}`);
          return final;
        });
      } else {
        console.warn(`⚠️ Senior home search: Status=${status}, no results or error`);
        // Don't clear existing senior homes on error
      }
    });
  }, []);

  const checkForAdjacentClinic = useCallback(async (pharmacy: PharmacyInfo): Promise<boolean> => {
    if (!placesServiceRef.current) return false;

    return new Promise((resolve) => {
      const request: google.maps.places.PlaceSearchRequest = {
        location: new google.maps.LatLng(pharmacy.lat, pharmacy.lng),
        radius: 50, // Search within 50 meters
        keyword: 'clinic'
      };

      placesServiceRef.current!.nearbySearch(request, (results, status) => {
        if (status === google.maps.places.PlacesServiceStatus.OK && results && results.length > 0) {
          // Check if any clinic is very close
          const hasClinic = results.some((place) => {
            if (!place.geometry?.location) return false;
            const distance = google.maps.geometry.spherical.computeDistanceBetween(
              new google.maps.LatLng(pharmacy.lat, pharmacy.lng),
              place.geometry.location
            );
            return distance <= 50; // Within 50 meters
          });
          resolve(hasClinic);
        } else {
          resolve(false);
        }
      });
    });
  }, []);

  const handleAddressSearch = useCallback((address: string) => {
    if (!geocoderRef.current || !map) return;

    setIsSearching(true);
    setSelectedPharmacy(null);
    setSelectedSeniorHome(null);

    geocoderRef.current.geocode({ address }, (results, status) => {
      if (status === 'OK' && results && results[0]) {
        const location = results[0].geometry.location;
        const newCenter = {
          lat: location.lat(),
          lng: location.lng()
        };
        
        const addressComponents = results[0].address_components;
        const locationData: LocationInfo = {
          city: '',
          province: '',
          town: undefined
        };

        addressComponents.forEach((component) => {
          if (component.types.includes('locality')) {
            locationData.city = component.long_name;
          }
          if (component.types.includes('sublocality') || component.types.includes('neighborhood')) {
            locationData.town = component.long_name;
          }
          if (component.types.includes('administrative_area_level_1')) {
            locationData.province = component.short_name;
          }
        });
        
        setCenter(newCenter);
        setSearchedAddress(address);
        setLocationInfo(locationData);
        setSearchedLocation(location);
        map.panTo(location);
        map.setZoom(14);
        
        searchPharmacies(location);
        searchGroceries(location, radius);
        searchSeniorHomes(location, radius);
      } else {
        console.error('Geocode failed:', status);
        setIsSearching(false);
      }
    });
  }, [map, radius, searchPharmacies, searchGroceries, searchSeniorHomes]);

  const handleClearSearch = useCallback(() => {
    setSearchedAddress(null);
    setAllPharmacies([]);
    setRawGroceries([]);
    setGroceries([]);
    setSeniorHomes([]);
    setSelectedPharmacy(null);
    setSelectedSeniorHome(null);
    setLocationInfo(null);
    setRadius(1000); // Reset to default 1km
    setHiddenPharmacies(new Set()); // Reset hidden pharmacies
    setHiddenSeniorHomes(new Set()); // Reset hidden senior homes
    setHiddenGroceries(new Set()); // Reset hidden groceries
    setHiddenRxCounts(new Set()); // Reset hidden Rx counts
    setSearchedLocation(null);
    setCenter(defaultCenter);
    if (map) {
      map.panTo(defaultCenter);
      map.setZoom(11);
    }
  }, [map]);

  const handleRadiusChange = useCallback((newRadius: number) => {
    setRadius(newRadius);
    // Radius now acts as a client-side filter, no need to re-fetch
    // Pharmacies are already fetched at 5km max, we just filter them
    // Groceries and senior homes still re-fetch since they don't have pagination
    if (searchedLocation) {
      searchGroceries(searchedLocation, newRadius);
      searchSeniorHomes(searchedLocation, newRadius);
    }
  }, [searchedLocation, searchGroceries, searchSeniorHomes]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const customRankings = await parseUploadedRankings(file);
        setRankingsMap(customRankings);
        alert(`Successfully loaded ${customRankings.size} rankings from ${file.name}`);
      } catch (error) {
        alert('Failed to parse Excel file. Please ensure it follows the correct format.');
      }
    }
  };

  const handleZoomIn = () => {
    if (map) {
      const currentZoom = map.getZoom() || 11;
      map.setZoom(currentZoom + 0.5);
    }
  };

  const handleZoomOut = () => {
    if (map) {
      const currentZoom = map.getZoom() || 11;
      map.setZoom(currentZoom - 0.5);
    }
  };

  const handleRemovePharmacy = useCallback((placeId: string) => {
    setHiddenPharmacies(prev => {
      const newSet = new Set(prev);
      newSet.add(placeId);
      return newSet;
    });
    setSelectedPharmacy(null);
  }, []);

  const handleRemoveSeniorHome = useCallback((placeId: string) => {
    setHiddenSeniorHomes(prev => {
      const newSet = new Set(prev);
      newSet.add(placeId);
      return newSet;
    });
    setSelectedSeniorHome(null);
  }, []);

  const handleRemoveGrocery = useCallback((placeId: string) => {
    setHiddenGroceries(prev => {
      const newSet = new Set(prev);
      newSet.add(placeId);
      return newSet;
    });
  }, []);

  const handleUnhideAll = useCallback(() => {
    setHiddenPharmacies(new Set());
    setHiddenSeniorHomes(new Set());
    setHiddenGroceries(new Set());
  }, []);

  const unhideItem = useCallback((id: string, type: 'pharmacy' | 'seniorHome' | 'grocery') => {
    if (type === 'pharmacy') {
      setHiddenPharmacies(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    } else if (type === 'seniorHome') {
      setHiddenSeniorHomes(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    } else if (type === 'grocery') {
      setHiddenGroceries(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  }, []);

  const handleToggleRxCount = useCallback((placeId: string) => {
    setHiddenRxCounts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(placeId)) {
        newSet.delete(placeId);
      } else {
        newSet.add(placeId);
      }
      return newSet;
    });
  }, []);

  // Filter pharmacies by selected radius (client-side)
  const pharmaciesInRadius = allPharmacies.filter(p => (p.distance ?? 0) <= radius);
  const visiblePharmacies = pharmaciesInRadius.filter(p => !hiddenPharmacies.has(p.placeId));
  const visibleSeniorHomes = seniorHomes.filter(sh => !hiddenSeniorHomes.has(sh.placeId));
  const visibleGroceries = groceries.filter(g => !hiddenGroceries.has(g.placeId));
  
  // Calculate scale factor based on zoom level (base zoom is 11)
  const getIconScale = useCallback(() => {
    const baseZoom = 11;
    // Only scale down when zooming out
    if (zoomLevel < baseZoom) {
      const scaleFactor = Math.pow(0.75, baseZoom - zoomLevel);
      return Math.max(0.3, scaleFactor); // Minimum 0.3x when zoomed out
    }
    // Keep original size when at base zoom or zoomed in
    return 1.0;
  }, [zoomLevel]);

  if (!isLoaded) {
    return (
      <div className="w-full h-screen flex items-center justify-center bg-background">
        <LoadingSpinner message="Loading map..." />
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      <div ref={headerRef} className="absolute top-0 left-0 right-0 z-10 bg-background/95 backdrop-blur-sm border-b">
        {!isMapMaximized ? (
          <div className="px-3 pt-3 pb-2 space-y-2">
            <div className="flex justify-between items-center px-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">RX Ranking Upload</span>
              <label className="cursor-pointer">
                <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileUpload} />
                <div className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded hover:bg-primary/20 transition-colors">
                  Upload .XLSX
                </div>
              </label>
            </div>
            <div className="flex gap-3 items-center flex-wrap">
              <div className="flex-1 min-w-0">
                <SearchBar 
                  onSearch={handleAddressSearch}
                  onClear={handleClearSearch}
                  isLoading={isSearching}
                  value={searchedAddress || ''}
                />
              </div>
              {searchedAddress && (
                <>
                  <div className="w-auto">
                    <RadiusControl radius={radius} onRadiusChange={handleRadiusChange} />
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowRxCounts(!showRxCounts)}
                    className="rounded-lg text-xs px-2"
                    data-testid="button-toggle-rx-counts"
                  >
                    {showRxCounts ? 'Hide Rx' : 'Show Rx'}
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setIsMapMaximized(true)}
                    className="rounded-lg"
                    data-testid="button-maximize-map"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                </>
              )}
            </div>
            {searchedAddress && locationInfo && (
              <div className="flex gap-3 flex-wrap items-center">
                <LocationDisplay 
                  city={locationInfo.city}
                  province={locationInfo.province}
                  town={locationInfo.town}
                />
                <div className="flex-1" />
                <CounterDisplay 
                  icon={Pill}
                  label="Pharmacies"
                  count={visiblePharmacies.length}
                  testId="counter-pharmacies"
                />
                <CounterDisplay 
                  icon={ShoppingCart}
                  label="Groceries"
                  count={visibleGroceries.length}
                  testId="counter-groceries"
                />
                <CounterDisplay 
                  icon={Home}
                  label="Senior Homes"
                  count={visibleSeniorHomes.length}
                  testId="counter-senior-homes"
                />
                {(hiddenPharmacies.size > 0 || hiddenSeniorHomes.size > 0 || hiddenGroceries.size > 0) && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-lg h-9 px-3"
                        data-testid="button-show-hidden-dropdown"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Show {hiddenPharmacies.size + hiddenSeniorHomes.size + hiddenGroceries.size} Hidden
                        <ChevronDown className="ml-2 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-64 max-h-80 overflow-y-auto">
                      <DropdownMenuLabel className="flex items-center justify-between">
                        <span>Hidden Items</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleUnhideAll}
                          className="h-auto p-0 text-xs text-primary hover:bg-transparent"
                        >
                          Unhide All
                        </Button>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      
                      {Array.from(hiddenPharmacies).map(id => {
                        const item = allPharmacies.find(p => p.placeId === id);
                        if (!item) return null;
                        return (
                          <DropdownMenuItem key={id} onClick={() => unhideItem(id, 'pharmacy')} className="flex items-center gap-2 cursor-pointer group">
                            <Pill className="w-3 h-3 text-muted-foreground" />
                            <span className="flex-1 truncate text-xs">{item.name}</span>
                            <Eye className="w-3 h-3 text-primary opacity-0 group-hover:opacity-100" />
                          </DropdownMenuItem>
                        );
                      })}
                      
                      {Array.from(hiddenGroceries).map(id => {
                        const item = rawGroceries.find(g => g.placeId === id);
                        if (!item) return null;
                        return (
                          <DropdownMenuItem key={id} onClick={() => unhideItem(id, 'grocery')} className="flex items-center gap-2 cursor-pointer group">
                            <ShoppingCart className="w-3 h-3 text-muted-foreground" />
                            <span className="flex-1 truncate text-xs">{item.name}</span>
                            <Eye className="w-3 h-3 text-primary opacity-0 group-hover:opacity-100" />
                          </DropdownMenuItem>
                        );
                      })}
                      
                      {Array.from(hiddenSeniorHomes).map(id => {
                        const item = seniorHomes.find(s => s.placeId === id);
                        if (!item) return null;
                        return (
                          <DropdownMenuItem key={id} onClick={() => unhideItem(id, 'seniorHome')} className="flex items-center gap-2 cursor-pointer group">
                            <Home className="w-3 h-3 text-muted-foreground" />
                            <span className="flex-1 truncate text-xs">{item.name}</span>
                            <Eye className="w-3 h-3 text-primary opacity-0 group-hover:opacity-100" />
                          </DropdownMenuItem>
                        );
                      })}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            )}
            {searchedAddress && locationInfo && (
              <LocationBreadcrumb 
                city={locationInfo.city}
                province={locationInfo.province}
                town={locationInfo.town}
                zoomLevel={zoomLevel}
              />
            )}
          </div>
        ) : (
          <div className="space-y-0">
            <div className="px-3 py-2 flex gap-2 items-center justify-end border-b">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleClearSearch}
                className="rounded-lg shadow-md"
                data-testid="button-new-search"
              >
                <RotateCcw className="w-3 h-3 mr-1.5" />
                New Search
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsMapMaximized(false)}
                className="rounded-lg px-2"
                data-testid="button-minimize-map"
              >
                <Minimize2 className="w-3 h-3" />
              </Button>
            </div>
            {searchedAddress && locationInfo && (
              <div className="px-3 py-1.5">
                <LocationBreadcrumb 
                  city={locationInfo.city}
                  province={locationInfo.province}
                  town={locationInfo.town}
                  zoomLevel={zoomLevel}
                />
              </div>
            )}
          </div>
        )}
      </div>

      <div className="w-full h-full" style={{ paddingTop: `${headerHeight}px` }}>
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={center}
          zoom={11}
          onLoad={onMapLoad}
          onUnmount={onMapUnmount}
          options={{
            streetViewControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
            zoomControl: false,
            scaleControl: false,
            styles: [
              {
                featureType: "poi",
                stylers: [{ visibility: "off" }]
              },
              {
                featureType: "poi.business",
                stylers: [{ visibility: "off" }]
              },
              {
                featureType: "poi.medical",
                elementType: "labels",
                stylers: [{ visibility: "off" }]
              }
            ]
          }}
        >
          {visiblePharmacies.map((pharmacy) => {
            const iconConfig = getPharmacyIcon(pharmacy.name);
            const scale = getIconScale();
            const scaledWidth = iconConfig.width * scale * 1.5; // 1.5x - reduced from 2x
            const scaledHeight = iconConfig.height * scale * 1.5; // 1.5x - reduced from 2x
            
            // Get prescription count for label (exclude Shoppers Drug Mart and Loblaw brands)
            const isShoppers = pharmacy.name.toLowerCase().includes('shoppers drug mart');
            const isLoblawBrand = LOBLAW_BRANDS.some(brand => 
              pharmacy.name.toLowerCase().includes(brand)
            );
            const rank = findRankByAddress(pharmacy.name, pharmacy.address, rankingsMap);
            const prescriptionCount = !isShoppers && !isLoblawBrand && rank && locationInfo?.province
              ? getPrescriptionCount(locationInfo.province, rank)
              : null;
            
            const labelText = showRxCounts && !hiddenRxCounts.has(pharmacy.placeId) && prescriptionCount !== null
              ? `(${(prescriptionCount / 1000).toFixed(0)}K rx)`
              : '';
            
            const handlePharmacyClick = async () => {
              const hasClinic = await checkForAdjacentClinic(pharmacy);
              const pharmacyWithRank = {
                ...pharmacy,
                rank: rank !== null ? rank : undefined,
                province: locationInfo?.province,
                hasAdjacentClinic: hasClinic
              };
              setSelectedPharmacy(pharmacyWithRank);
              setSelectedSeniorHome(null);
              setSelectedGrocery(null);
            };
            
            const handleDragEnd = (e: google.maps.MapMouseEvent) => {
              if (e.latLng) {
                const newLat = e.latLng.lat();
                const newLng = e.latLng.lng();
                
                // Update the pharmacy position in state (both lat/lng and displayLat/displayLng)
                setAllPharmacies(prev => prev.map(p => 
                  p.placeId === pharmacy.placeId
                    ? { ...p, lat: newLat, lng: newLng, displayLat: newLat, displayLng: newLng }
                    : p
                ));
              }
            };
            
            return (
              <Marker
                key={pharmacy.placeId}
                position={{ 
                  lat: pharmacy.displayLat || pharmacy.lat, 
                  lng: pharmacy.displayLng || pharmacy.lng 
                }}
                onClick={handlePharmacyClick}
                draggable={true}
                onDragEnd={handleDragEnd}
                icon={{
                  url: iconConfig.url,
                  scaledSize: new google.maps.Size(scaledWidth, scaledHeight),
                  anchor: new google.maps.Point(scaledWidth / 2, scaledHeight / 2)
                }}
                label={labelText ? {
                  text: labelText,
                  color: '#dc2626',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  className: 'pharmacy-label'
                } : undefined}
                zIndex={selectedPharmacy?.placeId === pharmacy.placeId ? 1000 : 2}
              />
            );
          })}
          
          {visibleGroceries.map((grocery) => {
            const scale = getIconScale();
            
            // Check if grocery is a Loblaw brand or has a matching pharmacy brand
            const isLoblawBrand = LOBLAW_BRANDS.some(brand => 
              grocery.name.toLowerCase().includes(brand)
            );
            
            // Try to get pharmacy icon for this grocery
            const pharmacyIconConfig = getPharmacyIcon(grocery.name);
            const independentFallback = getPharmacyIcon(''); // Get fallback to compare
            
            // Determine which icon to use:
            // 1. If matches any pharmacy brand (not the independent fallback), use that logo
            // 2. If Loblaw brand but no specific match, still use shopping cart (no generic Loblaw logo available)
            // 3. Otherwise, use shopping cart
            const hasPharmacyBrandMatch = pharmacyIconConfig.url !== independentFallback.url;
            const shouldUseBrandLogo = hasPharmacyBrandMatch;
            
            let iconUrl: string;
            let iconWidth: number;
            let iconHeight: number;
            
            if (shouldUseBrandLogo) {
              // Use brand logo (Walmart, Sobeys, Metro, Loblaws, No Frills, etc.)
              // Apply same 1.5x multiplier as pharmacy markers for consistent sizing
              iconUrl = pharmacyIconConfig.url;
              
              // Check if it's T&T for custom sizing
              const isTT = grocery.name.toLowerCase().includes('t&t') || grocery.name.toLowerCase().includes('t & t');
              if (isTT) {
                const baseSize = 40; // Same as senior home
                iconWidth = baseSize * scale;
                iconHeight = baseSize * scale;
              } else {
                iconWidth = pharmacyIconConfig.width * scale * 1.5;
                iconHeight = pharmacyIconConfig.height * scale * 1.5;
              }
            } else {
              // Use shopping cart for non-Loblaw or unmatched groceries
              const baseSize = 28;
              const scaledSize = baseSize * scale;
              iconUrl = 'data:image/svg+xml;base64,' + btoa(`
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="9" cy="21" r="1"></circle>
                  <circle cx="20" cy="21" r="1"></circle>
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
              `);
              iconWidth = scaledSize;
              iconHeight = scaledSize;
            }
            
            const handleGroceryClick = () => {
              setSelectedGrocery(grocery);
              setSelectedPharmacy(null);
              setSelectedSeniorHome(null);
            };
            
            return (
              <Marker
                key={grocery.placeId}
                position={{ lat: grocery.lat, lng: grocery.lng }}
                onClick={handleGroceryClick}
                draggable={true}
                onDragEnd={(e) => {
                  if (e.latLng) {
                    const newLat = e.latLng.lat();
                    const newLng = e.latLng.lng();
                    setRawGroceries(prev => prev.map(g => 
                      g.placeId === grocery.placeId ? { ...g, lat: newLat, lng: newLng } : g
                    ));
                  }
                }}
                icon={{
                  url: iconUrl,
                  scaledSize: new google.maps.Size(iconWidth, iconHeight),
                  anchor: new google.maps.Point(iconWidth / 2, iconHeight / 2)
                }}
                zIndex={selectedGrocery?.placeId === grocery.placeId ? 1000 : 1}
              />
            );
          })}
          
          {visibleSeniorHomes.map((seniorHome) => {
            const scale = getIconScale();
            const baseSize = 40;
            const scaledSize = baseSize * scale;
            
            const handleSeniorHomeClick = () => {
              setSelectedSeniorHome(seniorHome);
              setSelectedPharmacy(null);
              setSelectedGrocery(null);
            };

            return (
              <Marker
                key={seniorHome.placeId}
                position={{ lat: seniorHome.lat, lng: seniorHome.lng }}
                onClick={handleSeniorHomeClick}
                draggable={true}
                onDragEnd={(e) => {
                  if (e.latLng) {
                    const newLat = e.latLng.lat();
                    const newLng = e.latLng.lng();
                    setSeniorHomes(prev => prev.map(s => 
                      s.placeId === seniorHome.placeId ? { ...s, lat: newLat, lng: newLng } : s
                    ));
                  }
                }}
                icon={{
                  url: seniorHomeIcon,
                  scaledSize: new google.maps.Size(scaledSize, scaledSize),
                  anchor: new google.maps.Point(scaledSize / 2, scaledSize / 2)
                }}
                zIndex={selectedSeniorHome?.placeId === seniorHome.placeId ? 1000 : 1}
              />
            );
          })}
        </GoogleMap>
      </div>

      {searchedAddress && !isMapMaximized && (
        <>
          <div className="absolute bottom-4 left-4 z-10 flex flex-col gap-2">
            <Button
              variant="secondary"
              size="icon"
              onClick={handleZoomIn}
              className="rounded-lg shadow-md"
              data-testid="button-zoom-in"
            >
              <Plus className="w-5 h-5" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={handleZoomOut}
              className="rounded-lg shadow-md"
              data-testid="button-zoom-out"
            >
              <Minus className="w-5 h-5" />
            </Button>
          </div>

          <div className="absolute top-24 left-4 z-10">
            <Button
              variant="secondary"
              onClick={handleClearSearch}
              className="rounded-lg shadow-md"
              data-testid="button-new-search"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              New Search
            </Button>
          </div>
        </>
      )}
      
      {searchedAddress && isMapMaximized && (
        <div className="absolute bottom-4 left-4 z-10 flex flex-col gap-2">
          <Button
            variant="secondary"
            size="icon"
            onClick={handleZoomIn}
            className="rounded-lg shadow-md"
            data-testid="button-zoom-in"
          >
            <Plus className="w-5 h-5" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            onClick={handleZoomOut}
            className="rounded-lg shadow-md"
            data-testid="button-zoom-out"
          >
            <Minus className="w-5 h-5" />
          </Button>
        </div>
      )}

      {selectedPharmacy && (
        <div className="absolute bottom-4 right-4 z-10 max-w-sm">
          <PharmacyInfoCard
            pharmacy={selectedPharmacy}
            onClose={() => setSelectedPharmacy(null)}
            onRemove={handleRemovePharmacy}
            onToggleRxCount={handleToggleRxCount}
            isRxCountHidden={hiddenRxCounts.has(selectedPharmacy.placeId)}
          />
        </div>
      )}

      {selectedSeniorHome && (
        <div className="absolute bottom-4 right-4 z-10 max-w-sm">
          <SeniorHomeInfoCard
            seniorHome={selectedSeniorHome}
            onClose={() => setSelectedSeniorHome(null)}
            onRemove={handleRemoveSeniorHome}
          />
        </div>
      )}

      {selectedGrocery && (
        <div className="absolute bottom-4 right-4 z-10 max-w-sm">
          <GroceryInfoCard
            grocery={selectedGrocery}
            onClose={() => setSelectedGrocery(null)}
            onRemove={handleRemoveGrocery}
          />
        </div>
      )}

      {isSearching && (
        <div className="absolute inset-0 bg-background/50 backdrop-blur-sm flex items-center justify-center z-20">
          <LoadingSpinner message="Finding pharmacies, groceries, and senior homes..." />
        </div>
      )}
    </div>
  );
}
